Using
To build a theory you should run something like this:
> sudokuBV.exe example.txt theory.z3

To solve obtained theory run:
> z3 /z3 /m theory.z3